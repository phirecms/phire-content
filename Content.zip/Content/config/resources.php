<?php

return [
    'content' => [
        'index',
        'add',
        'edit',
        'remove'
    ],
    'content-types' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];