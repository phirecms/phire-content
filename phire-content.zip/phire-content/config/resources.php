<?php

return [
    'content' => [
        'index',
        'add',
        'edit',
        'in-edit',
        'copy',
        'search',
        'trash',
        'process'
    ],
    'content-types' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];